from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from .forms import CustomUserCreationForm, CustomUserChangeForm, ReservaForm
from .models import Habitacion, Reserva
from django.contrib import messages

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

@login_required
def home(request):
    habitaciones = Habitacion.objects.filter(disponible=True)
    return render(request, 'habitaciones/home.html', {'habitaciones': habitaciones})

@login_required
def detalle_habitacion(request, habitacion_id):
    habitacion = get_object_or_404(Habitacion, id=habitacion_id)
    return render(request, 'habitaciones/detalle.html', {'habitacion': habitacion})

@login_required
def reservar_habitacion(request, habitacion_id):
    habitacion = get_object_or_404(Habitacion, id=habitacion_id)
    if request.method == 'POST':
        form = ReservaForm(request.POST)
        if form.is_valid():
            reserva = form.save(commit=False)
            reserva.usuario = request.user
            reserva.habitacion = habitacion
            reserva.save()
            habitacion.disponible = False
            habitacion.save()
            messages.success(request, '¡Reserva realizada con éxito!')
            return redirect('home')
    else:
        form = ReservaForm()
    return render(request, 'reservas/reservar.html', {'form': form, 'habitacion': habitacion})

@login_required
def cancelar_reserva(request, reserva_id):
    reserva = get_object_or_404(Reserva, id=reserva_id, usuario=request.user)
    habitacion = reserva.habitacion
    reserva.delete()
    habitacion.disponible = True
    habitacion.save()
    messages.success(request, 'Reserva cancelada correctamente.')
    return redirect('mis_reservas')

@login_required
def mis_reservas(request):
    reservas = Reserva.objects.filter(usuario=request.user)
    return render(request, 'reservas/mis_reservas.html', {'reservas': reservas})

@login_required
def todas_las_reservas(request):
    if request.user.rol != 'ADMIN':
        return redirect('home')
    reservas = Reserva.objects.all()
    return render(request, 'reservas/todas_reservas.html', {'reservas': reservas})

@login_required
def editar_perfil(request):
    if request.method == 'POST':
        form = CustomUserChangeForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Perfil actualizado.')
            return redirect('home')
    else:
        form = CustomUserChangeForm(instance=request.user)
    return render(request, 'registration/editar_perfil.html', {'form': form})