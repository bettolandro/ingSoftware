from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('habitacion/<int:habitacion_id>/', views.detalle_habitacion, name='detalle_habitacion'),
    path('reservar/<int:habitacion_id>/', views.reservar_habitacion, name='reservar_habitacion'),
    path('cancelar/<int:reserva_id>/', views.cancelar_reserva, name='cancelar_reserva'),
    path('mis_reservas/', views.mis_reservas, name='mis_reservas'),
    path('todas_reservas/', views.todas_las_reservas, name='todas_reservas'),
    path('editar_perfil/', views.editar_perfil, name='editar_perfil'),
]